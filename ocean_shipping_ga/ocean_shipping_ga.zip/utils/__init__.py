"""
Utility functions
"""

from .runner import run_ocean_shipping_ga

__all__ = ["run_ocean_shipping_ga"]